import numpy as np
import matplotlib.pyplot as plt

data = np.loadtxt("LJ_VLcoex_rcut4sigma.dat", comments='#')

order = [0, 4, 1, 3, 2]
compound = ['Water', 'Ethanol', 'Methanol', 'Benzene', 'Toluene']
linestyle = ['k-', 'r-', 'm-', 'g-', 'b-']
#Antoine equation parameters: paramA, paramB, paramC
paramA = [16.3872, 16.8958, 16.5785, 13.7819, 13.9320]
paramB = [3885.70, 3795.17, 3638.27, 2726.81, 3056.96]
paramC = [-42.98, -42.232, -33.65, -55.578, -55.525]

T = np.arange(283,313,1) # Kelvins
NA = 6.02e23
kB = 8.314 / NA / 1000.0
sigma = 1.6

Psat = np.zeros([5,np.size(T)])
pljovertlj = np.zeros([5,np.size(T)])
epsilon = np.zeros([5,np.size(T)])

for i in range(len(compound)):
    for j in range( np.size(T)):
        Psat[i,j]= np.exp( paramA[i] - paramB[i] / (T[j] + paramC[i]) )

font = {'family': 'serif',
        'color':  'black',
        'weight': 'normal',
        'size': 28,
        }

T_LJ = data[:,0]
P_LJ = data[:,1]
rhoV_LJ = data[:,2]
rhoL_LJ = data[:,3]

x = 1. / T_LJ
y = np.log( P_LJ )

m, n = np.polyfit(x, y, 1)

xarray = np.arange(min(T_LJ), max(T_LJ), 0.0005)
yarray = np.exp( m / xarray +n )

for i in range(len(compound)):
    for j in range( np.size(T)):
        pljovertlj[i,j] = sigma**3.0 * 1e-27 / kB * (Psat[i,j]/T[j])
        minerror = 10.
        for k in range(np.size(xarray)):
            error = abs ( ( yarray[k] / xarray[k] - pljovertlj[i,j] ) / pljovertlj[i,j] )
            if (error < minerror):
                minerror = error
                kmin = k
        epsilon[i,j] = NA * kB * T[j] / xarray[kmin]

for j in range(len(compound)):
    i = order[j]
    plt.plot( T, epsilon[i,:], linestyle[i], label=compound[i])

plt.xlabel("$T_{system}$", fontdict=font)
plt.ylabel("$\epsilon$ (kJ/mol)", fontdict=font)
plt.xticks(fontsize=24)
plt.yticks(fontsize=24)
plt.legend(fontsize=20, ncol=2, loc='lower left')
plt.ylim(2.0,)
#plt.show()
plt.savefig("plot_epsilon_vs_T.pdf", bbox_inches="tight", format="pdf")

