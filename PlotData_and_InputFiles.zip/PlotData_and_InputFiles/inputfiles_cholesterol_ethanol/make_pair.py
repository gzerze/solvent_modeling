#This generates the lines in the LAMMPS input file related to pair interaction
# The units for LJ epsilon are converted from Martini (kj/mol) into LAMMPS real units (kcal/mol)
# The units for LJ sigma should be in Angstroms in the file inputted to this code

import numpy as np
import sys

sf = float ( sys.argv[1] )  # sigma factor, i.e., multiplied by sigma to adjust.
ef = float ( sys.argv[2] )  # epsilon factor, i.e., multiplied by epsilon to adjust.
#sf = 1.25

infile = open('NonBonded_parametrize.dat', "r")

lines = infile.readlines()

#dict = {}
ntype = 0

for i in range(len(lines)):
    line = lines[i].split()
    if line:
        if line[0].isnumeric():
            #dict[line[1]] = line[0]
            ntype += 1

mar_type = []

m = 0
for i in range(len(lines)):
    line = lines[i].split()
    if line:
        if line[0].isnumeric():
            m += 1
            if m != int(line[0]):
                print("ERROR in input file: order the types in ascending order")
                print(m, int(line[0]))
            mar_type.append( line[1] ) 

rcut = 64.0
print ("pair_style lj/smooth/linear ", rcut)
#print ("pair_style lj/smooth/linear 15")

for k in range( ntype ):
    for l in range ( k, ntype ):
        for i in range(len(lines)):
            line = lines[i].split()
            if line:
                #if line[0][0] != "#" and not line[0].isnumeric():
                if line[0] == mar_type[k] and line[1] == mar_type[l]:
                    eps = float ( line[2] ) * 0.239      # convert from kj/mol into kcal/mol
                    sigma = float ( line[3] )       #Already in Angstrom
                    if ( (k == 9 and l != 9 ) or (k != 9 and l == 9 ) ):
                        print("pair_coeff", k+1, l+1, eps*ef, sigma*sf, sigma*sf*4.0)     ## Ethanol cholesterol interactions are multiplied by sf factor
                    else:
                        print("pair_coeff", k+1, l+1, eps, sigma, sigma*4.0)

#                    print("pair_coeff", k+1, l+1, eps, sigma, 15)
                if line[0] == mar_type[l] and line[1] == mar_type[k] and k != l:
                    eps = float ( line[2] ) * 0.239      # convert from kj/mol into kcal/mol
                    sigma = float ( line[3] )       #Already in Angstrom
                    if ( (k == 9 and l != 9 ) or (k != 9 and l == 9 ) ):
                        print("pair_coeff", k+1, l+1, eps*ef, sigma*sf, sigma*sf*4.0)     ## Ethanol cholesterol interactions are multiplied by sf factor
                    else:
                        print("pair_coeff", k+1, l+1, eps, sigma, sigma*4.0)
#                    print("pair_coeff", k+1, l+1, eps, sigma, 15)





