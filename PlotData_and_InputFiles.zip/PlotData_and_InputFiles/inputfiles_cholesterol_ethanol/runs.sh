#!/bin/bash

p=`pwd`

for sf in 0.76 0.8 0.84 0.88 0.92 0.96 1.0
do
	mkdir $p/FactorialRuns/sf${sf}

	for ef in 0.80 0.85 0.90 0.95 1.0 1.05 1.1 1.15
	do
		mkdir $p/FactorialRuns/sf${sf}/ef${ef}

		cp $p/MasterDirectory/* $p/FactorialRuns/sf${sf}/ef${ef}/

		cat $p/FactorialRuns/sf${sf}/ef${ef}/in_upper.txt > $p/FactorialRuns/sf${sf}/ef${ef}/in.txt
		python make_pair.py ${sf} ${ef} >> $p/FactorialRuns/sf${sf}/ef${ef}/in.txt
		cat $p/FactorialRuns/sf${sf}/ef${ef}/in_lower.txt >> $p/FactorialRuns/sf${sf}/ef${ef}/in.txt

		rm $p/FactorialRuns/sf${sf}/ef${ef}/in_upper.txt
		rm $p/FactorialRuns/sf${sf}/ef${ef}/in_lower.txt

	done

done


