import numpy as np
import matplotlib.pyplot as plt

data = np.loadtxt("LJ_VLcoex_rcut4sigma.dat", comments='#')

order = [0, 4, 1, 3, 2]
compound = ['Water', 'Ethanol', 'Methanol', 'Benzene', 'Toluene']
linestyle_low = ['k-', 'r-', 'm-', 'g-', 'b-']
linestyle_hi = ['k-.', 'r-.', 'm-.', 'g-.', 'b-.']
#Antoine equation parameters: paramA, paramB, paramC
paramA = [16.3872, 16.8958, 16.5785, 13.7819, 13.9320]
paramB = [3885.70, 3795.17, 3638.27, 2726.81, 3056.96]
paramC = [-42.98, -42.232, -33.65, -55.578, -55.525]

T = [283, 313] # Kelvins
NA = 6.02e23
kB = 8.314 / NA / 1000.0

Psat_low = []
Psat_hi = []

for i in range(len(compound)):
    Psat_low.append( np.exp( paramA[i] - paramB[i] / (T[0] + paramC[i]) ) )

for i in range(len(compound)):
    Psat_hi.append( np.exp( paramA[i] - paramB[i] / (T[1] + paramC[i]) ) )

font = {'family': 'serif',
        'color':  'black',
        'weight': 'normal',
        'size': 28,
        }

T_LJ = data[:,0]
P_LJ = data[:,1]
rhoV_LJ = data[:,2]
rhoL_LJ = data[:,3]

x = 1. / T_LJ
y = np.log( P_LJ )

m, n = np.polyfit(x, y, 1)

xarray = np.arange(min(T_LJ), max(T_LJ), 0.002)
yarray = np.exp( m / xarray +n )

sigma_low = []
sigma_hi = []

for i in range(len(compound)):
    sigma_low.append( 1e9 * (kB*(yarray/xarray) / (Psat_low[i]/T[0]) )**(1./3.) )

for i in range(len(compound)):
    sigma_hi.append( 1e9 * (kB*(yarray/xarray) / (Psat_hi[i]/T[1]) )**(1./3.) )

for j in range(len(compound)):
    i = order[j]
    plt.plot( xarray, sigma_low[i], linestyle_low[i], label=compound[i])
    plt.plot( xarray, sigma_hi[i], linestyle_hi[i], label='')

plt.axhline(y = 1.6, color = 'k', linestyle = 'dotted')

plt.xlabel("$T_{LJ}$", fontdict=font)
plt.ylabel("$\sigma (nm)$", fontdict=font)
plt.xticks(fontsize=24)
plt.yticks(fontsize=24)
plt.fill_between(xarray, 1.4, 2.2, color='C1', alpha=0.2)
#plt.ylim([0.0004,0.11])
plt.legend(fontsize=20)
#plt.show()
plt.savefig("plot_sigma_vs_TLJ.pdf", bbox_inches="tight", format="pdf")

